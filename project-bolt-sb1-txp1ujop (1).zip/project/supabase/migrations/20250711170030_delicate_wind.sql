/*
  # Warehouse Management System Database Schema

  1. New Tables
    - `users` - User accounts for admin and operators
    - `forklifts` - Forklift fleet management
    - `tasks` - Task management and tracking
    - `task_history` - Historical task data with timestamps
    - `warehouse_config` - System configuration

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
    - Role-based access control

  3. Features
    - User authentication and role management
    - Forklift fleet tracking
    - Task lifecycle management
    - Performance analytics
*/

-- Users table for authentication and role management
CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  username text UNIQUE NOT NULL,
  email text UNIQUE,
  password_hash text NOT NULL,
  role text NOT NULL CHECK (role IN ('admin', 'operator')),
  forklift_id text,
  name text NOT NULL,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  last_login timestamptz,
  preferences jsonb DEFAULT '{}'::jsonb
);

-- Forklifts table for fleet management
CREATE TABLE IF NOT EXISTS forklifts (
  id text PRIMARY KEY,
  operator_name text NOT NULL,
  capacity integer NOT NULL DEFAULT 1000,
  fuel_capacity integer NOT NULL DEFAULT 100,
  battery_capacity integer NOT NULL DEFAULT 100,
  speed decimal DEFAULT 1.0,
  maintenance_status text DEFAULT 'good' CHECK (maintenance_status IN ('good', 'warning', 'critical')),
  position_x integer DEFAULT 3,
  position_y integer DEFAULT 4,
  current_load integer DEFAULT 0,
  fuel_level decimal DEFAULT 100,
  battery_level decimal DEFAULT 100,
  status text DEFAULT 'offline' CHECK (status IN ('idle', 'moving', 'picking', 'carrying', 'dropping', 'stuck', 'emergency', 'offline')),
  is_logged_in boolean DEFAULT false,
  total_distance decimal DEFAULT 0,
  total_time decimal DEFAULT 0,
  tasks_completed integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Tasks table for task management
CREATE TABLE IF NOT EXISTS tasks (
  id text PRIMARY KEY,
  task_type text NOT NULL CHECK (task_type IN ('inbound', 'outbound', 'internal')),
  material_name text NOT NULL,
  material_weight integer NOT NULL,
  material_priority text DEFAULT 'medium' CHECK (material_priority IN ('low', 'medium', 'high', 'urgent')),
  material_fragile boolean DEFAULT false,
  pickup_x integer NOT NULL,
  pickup_y integer NOT NULL,
  pickup_type text NOT NULL,
  pickup_shelf_id text,
  dropoff_x integer NOT NULL,
  dropoff_y integer NOT NULL,
  dropoff_type text NOT NULL,
  dropoff_shelf_id text,
  status text DEFAULT 'pending' CHECK (status IN ('pending', 'assigned', 'in-progress', 'picking', 'carrying', 'dropping', 'completed', 'cancelled')),
  priority_score integer DEFAULT 5,
  estimated_time decimal,
  actual_time decimal,
  assigned_forklift_id text REFERENCES forklifts(id),
  required_capacity integer NOT NULL,
  created_at timestamptz DEFAULT now(),
  assigned_at timestamptz,
  started_at timestamptz,
  completed_at timestamptz,
  created_by uuid REFERENCES users(id)
);

-- Task history for analytics and tracking
CREATE TABLE IF NOT EXISTS task_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  task_id text NOT NULL REFERENCES tasks(id),
  forklift_id text NOT NULL REFERENCES forklifts(id),
  status_change text NOT NULL,
  timestamp timestamptz DEFAULT now(),
  position_x integer,
  position_y integer,
  notes text,
  performance_metrics jsonb DEFAULT '{}'::jsonb
);

-- Warehouse configuration
CREATE TABLE IF NOT EXISTS warehouse_config (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  config_key text UNIQUE NOT NULL,
  config_value jsonb NOT NULL,
  description text,
  updated_at timestamptz DEFAULT now(),
  updated_by uuid REFERENCES users(id)
);

-- Enable Row Level Security
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE forklifts ENABLE ROW LEVEL SECURITY;
ALTER TABLE tasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE task_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE warehouse_config ENABLE ROW LEVEL SECURITY;

-- RLS Policies for users
CREATE POLICY "Users can read own data" ON users
  FOR SELECT TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Admins can read all users" ON users
  FOR SELECT TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users 
      WHERE id = auth.uid() AND role = 'admin'
    )
  );

CREATE POLICY "Admins can manage users" ON users
  FOR ALL TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users 
      WHERE id = auth.uid() AND role = 'admin'
    )
  );

-- RLS Policies for forklifts
CREATE POLICY "All authenticated users can read forklifts" ON forklifts
  FOR SELECT TO authenticated
  USING (true);

CREATE POLICY "Operators can update own forklift" ON forklifts
  FOR UPDATE TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users 
      WHERE id = auth.uid() AND forklift_id = forklifts.id
    )
  );

CREATE POLICY "Admins can manage all forklifts" ON forklifts
  FOR ALL TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users 
      WHERE id = auth.uid() AND role = 'admin'
    )
  );

-- RLS Policies for tasks
CREATE POLICY "All authenticated users can read tasks" ON tasks
  FOR SELECT TO authenticated
  USING (true);

CREATE POLICY "Operators can update assigned tasks" ON tasks
  FOR UPDATE TO authenticated
  USING (
    assigned_forklift_id IN (
      SELECT forklift_id FROM users WHERE id = auth.uid()
    )
  );

CREATE POLICY "Admins can manage all tasks" ON tasks
  FOR ALL TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users 
      WHERE id = auth.uid() AND role = 'admin'
    )
  );

-- RLS Policies for task_history
CREATE POLICY "All authenticated users can read task history" ON task_history
  FOR SELECT TO authenticated
  USING (true);

CREATE POLICY "System can insert task history" ON task_history
  FOR INSERT TO authenticated
  WITH CHECK (true);

-- RLS Policies for warehouse_config
CREATE POLICY "All authenticated users can read config" ON warehouse_config
  FOR SELECT TO authenticated
  USING (true);

CREATE POLICY "Admins can manage config" ON warehouse_config
  FOR ALL TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users 
      WHERE id = auth.uid() AND role = 'admin'
    )
  );

-- Insert default data
INSERT INTO users (username, password_hash, role, name, forklift_id) VALUES
  ('admin', 'admin123', 'admin', 'Warehouse Manager', NULL),
  ('operator1', 'password', 'operator', 'John Smith', 'forklift-1'),
  ('operator2', 'password', 'operator', 'Sarah Johnson', 'forklift-2'),
  ('operator3', 'password', 'operator', 'Mike Davis', 'forklift-3'),
  ('operator4', 'password', 'operator', 'Lisa Wilson', 'forklift-4'),
  ('operator5', 'password', 'operator', 'David Brown', 'forklift-5')
ON CONFLICT (username) DO NOTHING;

INSERT INTO forklifts (id, operator_name, capacity, fuel_capacity, battery_capacity) VALUES
  ('forklift-1', 'John Smith', 1000, 100, 100),
  ('forklift-2', 'Sarah Johnson', 1200, 100, 100),
  ('forklift-3', 'Mike Davis', 800, 100, 100),
  ('forklift-4', 'Lisa Wilson', 1500, 100, 100),
  ('forklift-5', 'David Brown', 1000, 100, 100)
ON CONFLICT (id) DO NOTHING;

INSERT INTO warehouse_config (config_key, config_value, description) VALUES
  ('simulation_settings', '{"learningRate": 0.1, "explorationRate": 0.3, "discountFactor": 0.9, "speed": 1.0}', 'Default simulation parameters'),
  ('warehouse_layout', '{"width": 35, "height": 25, "cellSize": 14}', 'Warehouse grid configuration'),
  ('safety_settings', '{"collisionAvoidance": true, "emergencyResponse": true, "weightManagement": true}', 'Safety system configuration')
ON CONFLICT (config_key) DO NOTHING;